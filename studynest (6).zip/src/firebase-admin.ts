import { getApps, initializeApp } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';

// Check if Firebase is already initialized
if (!getApps().length) {
  initializeApp({
      projectId: "dynamic-synthesis-3t8c4",
  });
}

const db = getFirestore("ai-studio-fa5d1d86-4ab2-4497-aeb0-748caaa266aa");

// API endpoint handlers

export async function syncUser(req, res) {
  try {
    const { uid, user } = req.body;
    if (!uid || !user) {
      return res.status(400).json({ error: 'Missing uid or user object' });
    }
    
    // Convert arrays/objects to fit Firestore if needed, or just store directly
    await db.collection('users').doc(uid).set(user, { merge: true });
    
    return res.status(200).json({ success: true });
  } catch (error) {
    console.error('Error syncing user:', error);
    return res.status(500).json({ error: 'Failed to sync user' });
  }
}

export async function syncUserData(req, res) {
  try {
    const { uid, key, val } = req.body;
    if (!uid || !key) {
      return res.status(400).json({ error: 'Missing uid or key' });
    }

    // We can store each piece of user data as a subcollection or document field
    await db.collection('users').doc(uid).collection('userData').doc(key).set({ data: val });
    
    return res.status(200).json({ success: true });
  } catch (error) {
    console.error('Error syncing user data:', error);
    return res.status(500).json({ error: 'Failed to sync data' });
  }
}

export async function getUserData(req, res) {
  try {
    const { uid, key } = req.params;
    if (!uid || !key) {
      return res.status(400).json({ error: 'Missing uid or key' });
    }

    const doc = await db.collection('users').doc(uid).collection('userData').doc(key).get();
    
    if (doc.exists) {
      return res.status(200).json({ success: true, data: doc.data().data });
    } else {
      return res.status(404).json({ success: false, error: 'Not found' });
    }
  } catch (error) {
    console.error('Error fetching user data:', error);
    return res.status(500).json({ error: 'Failed to fetch data' });
  }
}

export async function getUsers(req, res) {
    try {
        const usersSnapshot = await db.collection('users').get();
        const users = {};
        usersSnapshot.forEach(doc => {
            users[doc.id] = doc.data();
        });
        return res.status(200).json({ success: true, data: users });
    } catch (error) {
        console.error('Error fetching users:', error);
        return res.status(500).json({ error: 'Failed to fetch users' });
    }
}
